Hospo Dojo Web Tokens
---------------------
Files:
- hospo-dojo-brand-tokens.json  (design tokens)
- hospo-dojo-brand-tokens.css   (CSS variables + helpers)

Notes:
- Add @font-face for Gefika / Nimbus Sans / DM Sans in your app.
- Leather is a texture asset; replace the .hd-leather background-image URL.
- Use black text on white/ivory for long-form content.